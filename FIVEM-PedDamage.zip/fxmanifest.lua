fx_version 'cerulean'
game 'gta5'

client_script 'client.lua'

--MADE IN DUPAL / 참고 구조문  citizenfx SET_PED_CAN_LOSE_PROPS_ON_DAMAGE를 참고하여 제작되었습니다