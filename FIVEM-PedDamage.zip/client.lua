AddEventHandler('playerSpawned', function()
    local playerPed = PlayerPedId()

    Citizen.CreateThread(function()
        while true do
            SetPedCanLosePropsOnDamage(playerPed, false)
            Citizen.Wait(1000)
        end
    end)
end)